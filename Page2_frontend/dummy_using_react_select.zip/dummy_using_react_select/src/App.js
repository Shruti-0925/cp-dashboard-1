import './App.css';
import React, { Component } from 'react';
import Select from "react-select";
class App extends Component {
    constructor(props) {
        super(props)

        this.state = {
            data: [{ label: 'Educational Codeforces Round 122 (Rated for Div. 2)', value: 1633 },
             { label: 'Codeforces Round #769 (Div. 2)', value: 1632 },
             { label: 'Codeforces Round #768 (Div. 1)', value: 1630 },
             { label: 'Codeforces Round #768 (Div. 2)', value: 1631 },
             { label: 'Codeforces Round #767 (Div. 1)', value: 1628 },
             { label: 'Codeforces Round #767 (Div. 2)', value: 1629 },
             { label: 'Codeforces Round #766 (Div. 2)', value: 1627 },
             { label: 'Educational Codeforces Round 121 (Rated for Div. 2)', value: 1626 },
             { label: 'Codeforces Round #765 (Div. 2)', value: 1625 },
             { label: 'Codeforces Round #764 (Div. 3)', value: 1624 },
             { label: 'Hello 2022', value: 1621 }],
            dataisSelected: false,
            contestId: "",
            userselected: ""
        }
    }

    onchangee(e) {
        this.setState(prevState => ({ contestId: e.value, dataisSelected: true, userselected: e.label }))
    }
    render() {
        return (
          <div className="App">
                    <h1>Previous Contest</h1>
                    <Select options={this.state.data} onChange={this.onchangee.bind(this)} />
                    {
                        this.state.contestId === "" ? (<div><p>Please select any contest</p></div>) : (<div>
                            <p>Selected contest is {this.state.userselected},whose id is {this.state.contestId}</p></div>)
                    }
            </div>

        )
    }
}


export default App;
